var show=document.getElementById("contentHome");

document.body.onload = setupCanvas();
function setupCanvas(){
	var canvas = document.getElementById("session");
	var ctx;
	var xPositions = [];//画3个圈圈
	var	yPositions = [];
	var	colours = [];
	var	xspeed = [];
	var	yspeed = [];
	var	size = [];//泡泡大小 随机的变量数组
	var numBubbles = 3;
	var count=0;
	if (canvas.getContext) {
		ctx = canvas.getContext("2d");
		
		//add values to the arrays
		xPositions.push(75);//最上边
		yPositions.push(5);
		colours.push("rgb(194,26,67)");//194,26,67 红色   "rgb(" + r + "," + g + "," + b + ")"
		yspeed.push(5);//Y向
		xspeed.push(0);//X
		size.push(10);
		
		xPositions.push(5);//最左下角
		yPositions.push(145);
		colours.push("rgb(26,82,194)");//26,82,194 蓝色   "rgb(" + r + "," + g + "," + b + ")"
		//speed.push(5);//分解到 x y  
		yspeed.push(-5);//Y向
		xspeed.push(5);//X
		size.push(10);
		
		
		xPositions.push(145);//最右下角
		yPositions.push(145);
		colours.push("rgb(44,152,29)");// 44,152,29 绿色   "rgb(" + r + "," + g + "," + b + ")"
		//speed.push(5);//分解到 x y  
		yspeed.push(-5);//Y向
		xspeed.push(-5);//X
		size.push(10);
		
		console.log(xPositions);
		console.log(yPositions);
		
		
		// adding values to the size array
	
		var timer1=window.setInterval(draw, 300);	
			
	}//end if 
	function draw(){
		//code to be run every 50 milliseconds
		//drawing the background
		count++;
		ctx.fillStyle = "#FFFFFF";
		//alert('he');
		ctx.rect(0, 0, 150, 150);
		ctx.fill();
		for(var i = 0; i < numBubbles; i++){
			//fills with colour values from colours arrays
			ctx.fillStyle = colours[i];
			//draw bubbles
			ctx.beginPath();
			// modified to reference size array value
			ctx.arc(xPositions[i], yPositions[i], size[i], 0, Math.PI * 2, false);
			//ctx.fill();	//不填充	
			ctx.strokeStyle = colours[i];//画黑色线
			ctx.stroke();
	
			
			// animate
			// if the flower is off the canvas
			if(count==14){
				clearInterval(timer1);
			}
			else{
				yPositions[i] += yspeed[i];
				xPositions[i] += xspeed[i];
			}
			
		}
	}
	
	
}
function counselling() {
	show.innerHTML="";
	var hTag = document.createElement("h2");//创建 h标签
	hTag.innerHTML = "Counselling";
	var pTag = document.createElement("p");//创建 p标签
	pTag.innerHTML = "We offer both individual and group counselling sessions with trained professionals who can help you deal with any problems in your life or simple provide advice on ways to manage things a little better.";
	show.appendChild(hTag);
	show.appendChild(pTag);
	
}

function financial() {
	show.innerHTML="";
	var hTag = document.createElement("h2");//创建 h标签
	hTag.innerHTML = "Financial Services";
	var pTag = document.createElement("p");//创建 p标签
	pTag.innerHTML = "Our trained financial analysts can work with you to help you manage your finances and budget your income to achieve the financial goals that you want.";
	show.appendChild(hTag);
	show.appendChild(pTag);
	
}
function mental() {
	show.innerHTML="";
	var hTag = document.createElement("h2");//创建 h标签
	hTag.innerHTML = "Mental Health";
	var pTag = document.createElement("p");//创建 p标签
	pTag.innerHTML = "We offer a range of mental health support and coping services including counselling, meditation and mindfulness training, stress management and many more services.";
	show.appendChild(hTag);
	show.appendChild(pTag);
	
}
function family() {
	show.innerHTML="";
	var hTag = document.createElement("h2");//创建 h标签
	hTag.innerHTML = "Family Life";
	var pTag = document.createElement("p");//创建 p标签
	pTag.innerHTML ="If you are having difficulties at home, we offer a range of services to help including marriage counselling and parenting workshops."; 
	show.appendChild(hTag);
	show.appendChild(pTag);
	
}
function lifestyle() {
	show.innerHTML="";
	var hTag = document.createElement("h2");//创建 h标签
	hTag.innerHTML = "Lifestyle";
	var pTag = document.createElement("p");//创建 p标签
	pTag.innerHTML ="Having trouble losing weight, maintaining a healthy diet or general living a healthy lifestyle? WE have support services, lifestyle coaches, nutritionists and personal trainers for all levels here and waiting to help you become the best and healthiest you and to get you feeling good about yourself again.";
	show.appendChild(hTag);
	show.appendChild(pTag);
	
}


//5秒后显示 文字
				//$("#delayAnimation").attr({display: "none"});//    ????????not  working
				
				$("#delayAnimation").hide("fast"); //隐藏 动画
				$("#delayAnimation1").hide("fast"); //隐藏 动画
				$("#logoContainer1").hide("fast");//隐藏 logo
				
				/*
				$("#img2").attr({src: "../images/ladybug.png",
													alt:"a bad breakfast"
				});
				*/
				
				
				
				var myTimer = window.setInterval(myFunctionShow, 4000);
				function  myFunctionShow(){
					window.clearInterval(myTimer);
					//alert("定时器");
					$("#delayAnimation").slideDown(1500);//chu出现 动画
					$("#delayAnimation1").slideDown("slow");//出现 动画
					//隐藏动画  显示logo图片
					$("#canvasContainer").hide("fast");
					$("#logoContainer1").slideDown("slow");//出现 logo
					
					
					
				}
				
			

//5秒后显示 文字

