
//as soon as the document has been loaded
$(document).ready(function(){
	
	function update(){
		//create an ajax request
		$.ajax({
			type: "GET", //retrieving info, not posting it
			url: "../../php/students.php", //load our php
			dataType: "html", //expect html to be returned
			//if the ajax request worked
			success: function(response){
				//update our #staff list by 
				//inserting the result of our php code
				$("#student_list").html(response);
				//keep doing this every 5 seconds
				setTimeout(update, 5000);
			}
		});
	}
	update(); //calls the update function
});