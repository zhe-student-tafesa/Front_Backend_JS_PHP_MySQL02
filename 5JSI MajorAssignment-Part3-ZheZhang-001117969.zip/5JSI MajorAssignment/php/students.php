<?php
	//set up connection - host, username, password, database建立数据库连接
	$conn = new mysqli('localhost', 'root', '', 'tafe');
	
	//Check connection. If fails, show the error message
	if($conn->connect_error){
		die("Connection failed: " . $conn->connect_error);
	}
	//fetch records  //SQL查询语句
	$sql = "SELECT * FROM student";
	//run query, saves in variable called result
	$result = $conn->query($sql);//开始查询
	
	//if there's something in the table
	if($result->num_rows > 0){
		// start writing the table 打印表头
		echo "<table><tr><th>Picture</th><th>First Name</th><th>Surname</th><th>Email</th><th></th></tr>";
		// use a while loop to cycle through each student
		while($student = $result->fetch_assoc()){//遍历：查询得到的结果
			//						单引号	                                单引号：如何使用文件名拼接：src！！					
			echo "<tr><td><img src='../../images/".$student['profilePic']."' alt='".$student['firstName']." ".$student['surname']."'/></td>";
			echo "<td>".$student['firstName']."</td>";
			echo "<td>".$student['surname']."</td>";
			echo "<td>".$student['email']."</td>";
			echo "<td><a href='../edit.php?id=".$student['studentID']."'>Edit</a></td></tr>";//把Id传过去  通过超链接 ？？
		}
		echo "</table>";
	}else{
		//if there's nothing in the table to display
		echo "0 results returned";
	}	
	
?>