<!DOCTYPE html>
<html>

<head>
	<title>5JSI Session 8 Exercises</title>
	<meta charset="utf-8" />
	<link href="https://fonts.googleapis.com/css?family=Sofia" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>
	<?php
	$id = $_GET['id'];//通过链接传过来id   举例：点击第3个时，传过来id=3    http://localhost/tafe/html/edit.php?id=3
	$firstName;
	$surname;
	$email;
	$imageName;
	$sql = "SELECT * FROM student WHERE studentID = " . $id; //根据传过来 的id读取数据库
	$conn = new mysqli('localhost', 'root', '', 'tafe');
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while ($student = $result->fetch_assoc()) {
			$firstName = $student['firstName']; // cong从数据库查出的要修改的人员信息
			$surname = $student['surname'];
			$email = $student['email'];
			$imageName = $student['profilePic'];
		}
	}
	?>
	<div id="container">
		<header>
			<h1 class="bus_name">TAFE - Students</h1>
		</header>
		<nav>
			<ul>
				<li><a class="active" href="../index.php">Home</a></li>
				<li><a href="secure/students.php">Students</a></li>
				<li><a href="add.php">Add Student</a></li>
			</ul>
		</nav>
		<section class="homesect">
			<h1 id="firstHeading" class="blueTxt">Edit a Student</h1>
			<!-- 在form 里显示原来的数据 -->
			<form method="post" enctype="multipart/form-data">
				<p>
					<label for="firstName">First Name:</label>
					<input type="text" name="firstName" id="firstName" <?php echo "value='" . $firstName . "'"; ?>>
				</p>
				<p>
					<label for="surname">Surname:</label>
					<input type="text" name="surname" id="surname" <?php echo "value='" . $surname . "'"; ?>>
				</p>
				<p>
					<label for="email">Email:</label>
					<input type="text" name="email" id="email" <?php echo "value='" . $email . "'"; ?>>
				</p>
				<p>
					<label for="imgName">Image Name:</label>
					<input type="text" name="imgName" id="imgName" <?php echo "value='" . $imageName . "'"; ?>>
				</p>
				<input class="btn" type="submit" name="submit" value="Update">

			</form>
			<br />
			<br />
			<br />

			<!-- 表单提交事件 -->
			<?php
			//connection - host, username, password, database
			$conn = new mysqli('localhost', 'root', '', 'tafe');
			//Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}

			//if we submit our form (form 'submit' is true/posted)
			if (isset($_POST['submit'])) {
				//grab the content of each field using its field name
				//and save info in a variable
				//uses the escape string method to escape user inputs for security
				//this technique ignores special characters
				// 读取form里面的最新数据
				$firstName = mysqli_real_escape_string($conn, $_REQUEST['firstName']);
				$surname = mysqli_real_escape_string($conn, $_REQUEST['surname']);
				$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
				$imageName = mysqli_real_escape_string($conn, $_REQUEST['imgName']);
				//attempt to insert data into table - all insert queries should be on one line
				//更新数据库 SQL语句
				$sql = "UPDATE student SET firstName = '$firstName', surname = '$surname', email = '$email', profilePic = '$imageName' WHERE studentID = $id";
				//if it worked, show message
				if (mysqli_query($conn, $sql)) {
					echo "<p>Record updated successfully.</p>";
				} else {
					//if not, show error
					echo "<p>ERROR: Was not able to execute update.";
					echo mysqli_error($conn) . "</p>";
				}
			}
			?>



		</section>
		<footer>
			<p>
				<?php
				//adds a copyright sign and the current year to the page
				echo "&nbsp;&copy;&nbsp;TAFE SAo&nbsp;" . date("Y");
				?>
			</p>
		</footer>

	</div>



</body>

</html>