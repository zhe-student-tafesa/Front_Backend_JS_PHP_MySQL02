<?php
// set up connection - host, username, password, database     连接数据库
$conn = new mysqli('localhost', 'root', '', 'tranquildb');

// Check connection. If fails, show the error message
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

//fetch records
// create a variable, vars start with $  
// We're selecting all (using the wildcard operator *) 
// from our staff table
$sql = "SELECT * FROM employees";//查询语句   

// run query, saves in variable called result
$result = $conn->query($sql);//查询   所有的 员工
?>
<!DOCTYPE html>
<html>
<head>
	<title>Tranquil Services</title>
	<meta charset="utf-8" />
	<link href="https://fonts.googleapis.com/css?family=Sofia" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	
	<!--MUST INCLUDE A LINK TO JQUERY-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/style.css" />
	
</head>
<body>
	<div id="container">
	<header  >
		<h1 class="bus_name" id="businessName">Tranquil Services</h1>
	</header>
		<div id="logoContainer">
			<img src="../images/logo.png" alt="logo"/>

		</div>
	<nav>
		<ul>
			<li><a  href="../index.html">Home</a></li>
			<li><a class="active" href="about.php">About</a></li>
			<!-- 超链接，html文件夹的add.php -->
			<li><a href="contact.html">Contact</a></li>
			<li><a href="news.html">News</a></li>
		</ul>
	</nav>
	<section>
		<h1 id="firstHeading" class="blueTxt">Welcome to the Tranquil Services Website</h1>

		<div id="contentAbout">
			<span>
				We would also like to have an About page where we can detail a bit more about our company and purpose. 
				We have provided a small blurb for this page that we’d like to appear here.
				We’d also like there to be some overall information on our employees and what they specialise in.
				We’d like our employees’ information to be kept in a database for our general use, 
				but we’d like to use that database to display some of their information on this page for the public to see 
				(qualifications, area of specialty, etc).
			</span>
			
		</div>
		<h2 id="firstHeading" class="blueTxt">Our friendly staff</h2>
		<div id="staff_list">
						<?php
						// if there's something in the table
						if ($result->num_rows > 0) {
							// use a while loop to cycle through each employee
							while ($employee = $result->fetch_assoc()) {//查询 结果 保存在 employee中，遍历 cycle取出，打印
								// create a new div to display the info  111111111111
								echo "<div class='profileStyle'>";
								// insert the picture by grabbing the 'image' field from our
								// data table using the 'firstName' field as our alt text
		
								//22222222222222222
		
								//增加一个img标签，src='data:image/jpeg;base64, 图片数据解码（base64_encode($employee['image'])）， alt ='" . $employee['firstName'] . "'
		
								echo "<img src='data:image/jpeg;base64, ";
								echo base64_encode($employee['profilePic']);
								echo "' alt ='" . $employee['firstName'] . "' />";
								// grab the first and last names and display them
								echo "<p><b>" . $employee['firstName'] . " ";//33333333  firstName
								echo $employee['surName'] . "</b><br />";//44444444444444444 lastName
								// display the quote and close the profile div
								echo "Areas Of Expertise: ".$employee['AreasOfExpertise'] . "</p></div>";//////////55  quote
							}
						} else {
							// if there's nothing in the table to display
							echo "0 results returned";
						}
						?>
		
					</div>
		
		</br></br></br></br>
	</section>
	<footer>
	<p>
		
				This site was developed by Zhe Zhang ITWorks  &nbsp;©&nbsp;Tranquil Services &nbsp;2021 
			
	</p>
	</footer>
	
	</div>
	<!-- <script src="../js/majorAssignment.js"></script> -->

</body>
</html>