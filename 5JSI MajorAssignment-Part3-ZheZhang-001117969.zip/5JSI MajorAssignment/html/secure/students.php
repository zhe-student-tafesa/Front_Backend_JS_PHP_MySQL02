<!DOCTYPE html>
<html>

<head>
	<title>5JSI Session 8 Exercises</title>
	<meta charset="utf-8" />
	<link href="https://fonts.googleapis.com/css?family=Sofia" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../../css/style.css" />
	<!--MUST INCLUDE A LINK TO JQUERY-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
	<div id="container">
		<header>
			<h1 class="bus_name">TAFE - Students</h1>
		</header>
		<nav>
			<!-- 导航栏 -->
			<ul>
				<li><a class="active" href="../../index.php">Home</a></li>
				<li><a href="#">Students</a></li>
				<li><a href="../add.php">Add Student</a></li>
			</ul>
		</nav>
		<section>
			<h1 id="firstHeading" class="blueTxt">Students</h1>

			<div id="student_list">
				<?php
				include('../../php/students.php');
				?>
			</div>
		</section>
		<footer>
			<p>
				<?php
				//adds a copyright sign and the current year to the page
				echo "&nbsp;&copy;&nbsp;TAFE SA&nbsp;" . date("Y");
				?>
			</p>
		</footer>

	</div>
	<script src="../../js/script.js"></script>

</body>

</html>