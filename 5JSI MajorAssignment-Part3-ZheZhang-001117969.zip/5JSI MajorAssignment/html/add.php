<!DOCTYPE html>
<html>

<head>
	<title>5JSI Session 8 Exercises</title>
	<meta charset="utf-8" />
	<link href="https://fonts.googleapis.com/css?family=Sofia" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body>
	<div id="container">
		<header>
			<h1 class="bus_name">TAFE - Students</h1>
		</header>
		<nav>
			<ul>
				<li><a class="active" href="../index.php">Home</a></li>
				<li><a href="secure/students.php">Students</a></li>
				<li><a href="#">Add Student</a></li>
			</ul>
		</nav>
		<section class="homesect">
			<h1 id="firstHeading" class="blueTxt">Add a Student</h1>
			<form method="post" enctype="multipart/form-data">
			<!-- 只有使用了multipart/form-data，才能完整的传递文件数据 -->
				<!-- name属性很重要 -->
				<p>
					<label for="firstName">First Name:</label>
					<input type="text" name="firstName" id="firstName">
				</p>
				<p>
					<label for="surname">Surname:</label>
					<input type="text" name="surname" id="surname">
				</p>
				<p>
					<label for="email">Email:</label>
					<input type="text" name="email" id="email">
				</p>
				<p>
					<label for="imgName">Image Name:</label>
					<input type="text" name="imgName" id="imgName">
				</p>
				<input class="btn" type="submit" name="submit" value="Submit">

			</form>
			<br />
			<br />
			<br />
			<?php
			//connection - host, username, password, database
			$conn = new mysqli('localhost', 'root', '', 'tafe');
			//Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}

			//if we submit our form (form 'submit' is true/posted)
			if (isset($_POST['submit'])) {//如果点击提交按钮则 true
				//grab the content of each field using its field name
				//and save info in a variable
				//uses the escape string method to escape user inputs for security
				//this technique ignores special characters
				$firstName = mysqli_real_escape_string($conn, $_REQUEST['firstName']);
				$surname = mysqli_real_escape_string($conn, $_REQUEST['surname']);
				$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
				$imageName = mysqli_real_escape_string($conn, $_REQUEST['imgName']);
				//attempt to insert data into table - all insert queries should be on one line//插入时，不需要id，因为它是自动增长
				$sql = "INSERT INTO student (firstName, surname, email, profilePic) VALUES ('$firstName', '$surname', '$email', '$imageName')";//把文件名 保存
				//if it worked, show message
				if (mysqli_query($conn, $sql)) {
					echo "<p>Record added successfully.</p>";
				} else {
					//if not, show error
					echo "<p>ERROR: Was not able to execute $sql. ";
					echo mysqli_error($conn) . "</p>";
				}
			}
			?>
		</section>
		<footer>
			<p>
				<?php
				//adds a copyright sign and the current year to the page
				echo "&nbsp;&copy;&nbsp;TAFE SA&nbsp;" . date("Y");
				?>
			</p>
		</footer>

	</div>



</body>

</html>